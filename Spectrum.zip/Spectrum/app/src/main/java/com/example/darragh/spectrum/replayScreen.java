package com.example.darragh.spectrum;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public class replayScreen extends ActionBarActivity
{
    /*  Declaring global objects needed for this activity    */
    Intent replayIn;
    int score;
    String bestScoreString;

    @Override
    protected void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_replay_screen);


       /*getting score from game*/
        Bundle extras = getIntent().getExtras();
        score = extras.getInt("scr");
        /*Initialising object and variables*/
        replayIn = new Intent(this, Game.class);
        Button replay = (Button) findViewById(R.id.buttonReplay);
        Button quitB  = (Button) findViewById(R.id.buttonQUITre);
        TextView scoreView = (TextView)(findViewById(R.id.textView2));
        int bestScore;
        scoreView.setText("Score = " + score);
        String file = "score.txt";
        int c;
        String best = "";


        FileInputStream inStream = null;
        try
		{
            inStream = openFileInput(file);
            while((c = inStream.read()) != -1)
			{
                best += "" + Character.toString((char) c);
            }
            inStream.close();
        }
		
		catch (FileNotFoundException e)
		{
            e.printStackTrace();
        }
		catch (IOException e)
		{
            e.printStackTrace();
        }
		
        if(!best.isEmpty())
			bestScore = Integer.parseInt(best);
        
		else 
			bestScore = 0;

        if(bestScore < score)
            bestScore = score;
        
		bestScoreString = "" + bestScore;

        writeFile();

        /*setting button listeners*/
        replay.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				replayM();
			}
		});
        
		quitB.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				writeFile();
				System.exit(0);
				finish();
            }
		});
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu)
	{
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_replay_screen, menu);
        return true;
    }

	
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
	{
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings)
			return true;

        return super.onOptionsItemSelected(item);
    }

	/*A method to switch to the game activity*/
    public void replayM()
	{
        writeFile();
        startActivity(replayIn);
        finish();
    }
	
	/*A method to write to memory to store the best score */
    public void writeFile()
	{
        FileOutputStream outputStream;
        try
		{
            outputStream = openFileOutput("score.txt", Context.MODE_PRIVATE);
            outputStream.write(bestScoreString.getBytes());
            outputStream.close();
        }
		
		catch (Exception e)
		{
            e.printStackTrace();
        }
    }
}
