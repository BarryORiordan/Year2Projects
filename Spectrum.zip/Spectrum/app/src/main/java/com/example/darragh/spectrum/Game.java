package com.example.darragh.spectrum;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class Game extends ActionBarActivity
{
    /*  Declaring global objects needed for this activity    */
     TextView timerWindow;
     TextView scoreBoard;
     CountDownTimer CountTimer;
     Button butt1, butt2, butt3, butt4;
     Intent replayScreen;

    /*Declaring and initialising the rgb values for each buttons text colour*/
    int[] colourOfText1 = {255, 255, 0};
    int[] colourOfText2 = {255, 255, 0};
    int[] colourOfText3 = {255, 255, 0};
    int[] colourOfText4 = {255, 255, 0};

    /* Integers for the score, and which buttons is the correct answer*/
    int score, rightButton;

    /*Strings for text the buttons display*/
    String colour1, colour2, colour3, colour4;

    @Override
    protected void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        /*initialising objects declared above, when the app is created.*/
        timerWindow = (TextView) findViewById(R.id.textView3);
        scoreBoard  = (TextView) findViewById(R.id.textViewSCORE);
        scoreBoard.setText("Score: 0");
        replayScreen = new Intent (this,replayScreen.class);


        /*initialising each button and setting up listeners */
        butt1 = (Button) findViewById(R.id.button2);
        butt1.setOnClickListener(new View.OnClickListener()
		{ 
			@Override
			public void onClick(View v)
			{
				buttonPressed(1);
			}
        });

        butt2 = (Button) findViewById(R.id.button3);
        butt2.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				buttonPressed(2);
			}
        });

        butt3 = (Button) findViewById(R.id.button4);
        butt3.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				buttonPressed(3);
			}
		});

        butt4 = (Button) findViewById(R.id.button5);
        butt4.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				buttonPressed(4);
			}
		});


        /* This method call, calls on a method that uses Math.random to select 1 of the 4 buttons as the correct answer
        * and also generates the text colours and text of the buttons
        * */
        getColours();

        /* The CountDownTimer object is then initialised and set. */
        CountTimer = new CountDownTimer(3000, 1)
		{
            public void onTick(long millisUntilFinished)
			{
                timerWindow.setText("" + millisUntilFinished);
            }

            public void onFinish()
			{
                gameOver();
                finish();
            }
        };
		CountTimer.start();
	}


    @Override
    public boolean onCreateOptionsMenu(Menu menu)
	{
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_game, menu);
        return true;
    }
	

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
	{
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings)
            return true;

        return super.onOptionsItemSelected(item);
    }


    public void getColours(){


        String Xcolour1, Xcolour2, Xcolour3, Xcolour4;
        int randoNum;
        String NOTcolour1, NOTcolour2, NOTcolour3;

        /* Each string is then returned a string containing a random colour*/
        Xcolour1 = getRandomColour("");
		Xcolour2 = getRandomColour("");		
		Xcolour3 = getRandomColour("");
		Xcolour4 = getRandomColour("");


        /*Getting button that will be the correct answer*/
        randoNum = 1 + (int) (Math.random() * 4);
        switch(randoNum)
		{
            case 1:	rightButton = 1;	break;
            case 2:	rightButton = 2;	break;
            case 3:	rightButton = 3;	break;
            case 4:	rightButton = 4;	break;
        }

        /* Get corresponding correct colour for the button that will be the correct answer
        * and set the other buttons to textcolours that don't match
        * Do this for each case, for each right button*/
        if(rightButton == 1)
		{
            NOTcolour1 = getRandomColour(Xcolour2);
            NOTcolour2 = getRandomColour(Xcolour3);
            NOTcolour3 = getRandomColour(Xcolour4);

            colourOfText1 = getTextColour(Xcolour1);
			
            colourOfText2 = getTextColour(NOTcolour1);
            colourOfText3 = getTextColour(NOTcolour2);
            colourOfText4 = getTextColour(NOTcolour3);
			
            colour1 = Xcolour1;
            colour2 = Xcolour2;
            colour3 = Xcolour3;
            colour4 = Xcolour4;
        }
		
        else if(rightButton == 2)
		{
            NOTcolour1 = getRandomColour(Xcolour1);
            NOTcolour2 = getRandomColour(Xcolour3);
            NOTcolour3 = getRandomColour(Xcolour4);

            colourOfText2 = getTextColour(Xcolour2);
			
            colour2 = Xcolour2;
            colour1 = Xcolour1;
            colour3 = Xcolour3;
            colour4 = Xcolour4;
			
            colourOfText1 = getTextColour(NOTcolour1);
            colourOfText3 = getTextColour(NOTcolour2);
            colourOfText4 = getTextColour(NOTcolour3);

        }
		
        else if(rightButton == 3)
		{
            NOTcolour1 = getRandomColour(Xcolour4);
            NOTcolour2 = getRandomColour(Xcolour2);
            NOTcolour3 = getRandomColour(Xcolour1);
			
            colourOfText3 = getTextColour(Xcolour3);
			
            colourOfText1 = getTextColour(NOTcolour3);
            colourOfText2 = getTextColour(NOTcolour2);
            colourOfText4 = getTextColour(NOTcolour1);
			
            colour3 = Xcolour3;
            colour4 = Xcolour4;
            colour2 = Xcolour2;
            colour1 = Xcolour1;

        }
		
        else if(rightButton == 4)
		{
            NOTcolour1 = getRandomColour(Xcolour1);
            NOTcolour2 = getRandomColour(Xcolour2);
            NOTcolour3 = getRandomColour(Xcolour3);
			
            colourOfText4 = getTextColour(Xcolour4);
			
            colour4 = Xcolour4;
            colour1 = Xcolour1;
            colour2 = Xcolour2;
            colour3 = Xcolour3;
			
            colourOfText1 = getTextColour(NOTcolour1);
            colourOfText2 = getTextColour(NOTcolour2);
            colourOfText3 = getTextColour(NOTcolour3);

        }

        /*A method call to set the text and text colour of the buttons, using the variables set above*/
        setButtons();
    }

	/*gets random colour using Math.random*/
    public String getRandomColour(String notColour)
	{
        String colour = "";
        int randoNum, randomNum2;

        randoNum = 1 + (int) (Math.random() * 10);
		// Math.floor(Math.random() * (max - min + 1)) + min

        switch(randoNum)
		{
			case 1:	 colour = "Blue"	;break;
			case 2:	 colour = "Red"		;break;
			case 3:	 colour = "Yellow"	;break;
			case 4:	 colour = "Green"	;break;
			case 5:	 colour = "Purple"	;break;
			case 6:	 colour = "Black"	;break;
			case 7:	 colour = "Brown"	;break;
			case 8:	 colour = "White"	;break;
			case 9:	 colour = "Orange"	;break;
			case 10: colour = "Pink"	;break;
		}
		
        if(colour == notColour)
		{
            randomNum2 = 1 + (int) (Math.random() * 10);
            if(randomNum2 == randoNum)
                randomNum2 = 1 + (int)(Math.random() * 10);

            switch(randomNum2)
			{
                case 1:	 colour = "Blue"	;break;
                case 2:	 colour = "Red"		;break;
                case 3:	 colour = "Yellow"	;break;
                case 4:	 colour = "Green"	;break;
                case 5:	 colour = "Purple"	;break;
                case 6:	 colour = "Black"	;break;
                case 7:	 colour = "Brown"	;break;
                case 8:	 colour = "White"	;break;
                case 9:	 colour = "Orange"	;break;
                case 10: colour = "Pink"	;break;
            }
        }
        return colour;
	}


    /*Method to assign rgb value of a colour*/
    public int[] getTextColour(String colour)
	{
		int red = 0, green= 1, blue = 2;
		int [] rgb = {1, 1, 1};
		
		switch (colour)
		{
            case "Blue":	rgb[red]   = 0;
							rgb[green] = 0;
							rgb[blue]  = 255;
			break;
            case "Red":		rgb[red]   = 255;
							rgb[green] = 0;
							rgb[blue]  = 0;
            break;
            case "Yellow":	rgb[red]   = 255;
							rgb[green] = 255;
							rgb[blue]  = 0;
            break;
            case "Green":	rgb[red]   = 0;
							rgb[green] = 255;
							rgb[blue]  = 0;
            break;
            case "Purple":	rgb[red]   = 128;
							rgb[green] = 0;
							rgb[blue]  = 128;
            break;
            case "Black":	rgb[red]   = 0;
							rgb[green] = 0;
							rgb[blue]  = 0;
            break;
            case "Brown":	rgb[red]   = 102;
							rgb[green] = 51;
							rgb[blue]  = 0;
            break;
            case "White":	rgb[red]   = 255;
							rgb[green] = 255;
							rgb[blue]  = 255;
            break;
            case "Orange":	rgb[red]   = 250;
							rgb[green] = 110;
							rgb[blue]  = 0;
            break;
            case "Pink":	rgb[red]   = 255;
							rgb[green] = 105;
							rgb[blue]  = 180;
            break;
        }
        return rgb;

    }
	
	/*This function is called form inside the listeners of each button.
	* It is passed and int value for each button, it corresponded to which buttons was pressed.
	* Decides what to do if the right or wrong button was pressed*/
    public void buttonPressed(int buttonNum)
	{
        //Cancel timer
        //Check weather button was the right answer
        if(buttonNum == rightButton)
		{
            CountTimer.start();
            score++;
            scoreBoard.setText("Score: "+score);
            
			getColours();
        }
        
		else
		{
            CountTimer.cancel();
            gameOver();
        }

        getColours();
	}

	/* Sets buttons. called from get colours after variables are set*/
    public void setButtons()
	{
        butt1.setText(colour1);
        butt1.setTextColor(Color.rgb(colourOfText1[0], colourOfText1[1], colourOfText1[2]));

        butt2.setText(colour2);
        butt2.setTextColor(Color.rgb(colourOfText2[0], colourOfText2[1], colourOfText2[2]));

        butt3.setText(colour3);
        butt3.setTextColor(Color.rgb(colourOfText3[0], colourOfText3[1], colourOfText3[2]));

        butt4.setText(colour4);
        butt4.setTextColor(Color.rgb(colourOfText4[0], colourOfText4[1], colourOfText4[2]));
	}


    /*Method to call when gameover conditions are met*/
    public void gameOver()
	{
        CountTimer.cancel();
        replayScreen.putExtra("scr", score);
        startActivity(replayScreen);
        finish();
    }
}