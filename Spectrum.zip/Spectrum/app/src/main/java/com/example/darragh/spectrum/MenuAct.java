package com.example.darragh.spectrum;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;


public class MenuAct extends ActionBarActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        /*Reading best score from memory and check */
        String file = "score.txt";
        int c;
        String best = "BEST: ";

        FileInputStream inStream = null;
        try
		{
            inStream = openFileInput(file);
            while((c = inStream.read()) != -1)
			{
                best += Character.toString((char)c);
			}
            inStream.close();
        }
		
		catch(FileNotFoundException e)
		{
            e.printStackTrace();
		}
		
		catch (IOException e)
		{
            e.printStackTrace();
        }

        /*Setting text view with the best score*/
        TextView bestScore = (TextView) findViewById(R.id.textView2);
        bestScore.setText(best);

        /*Initialising buttons and intent
        * ands setting listeners for buttons*/
        final Intent startGame = new Intent(this, Game.class);
        Button playBut = (Button) findViewById(R.id.buttonPLAY);
        playBut.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				startActivity(startGame);
                finish();
			}
		});

        Button quitBut = (Button) findViewById(R.id.button);
        quitBut.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v) 
			{
				System.exit(0);
				finish();
            }
		});
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu)
	{
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_menu, menu);
        return true;
    }

	
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
	{
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings)
            return true;

        return super.onOptionsItemSelected(item);
    }
}